#include <stdio.h>
#include <string.h>

#include "sbox.h"

#define ENCRYPT 0
#define DECRYPT 1

#define fail_null(out, x, ...)\
	do {\
		if ((out = x(__VA_ARGS__)) == NULL) {\
			perror(#x);\
			result = 1;\
			goto done;\
		}\
	} while(0)

#define fail_not_zero(x, ...)\
	do {\
		result = (x(__VA_ARGS__));\
		if (result) {\
			perror(#x);\
			goto done;\
		}\
	} while(0)

void substitute(unsigned char *buf, const unsigned char *matrix)
{
	int i;
	for (i = 0; i < 16; i++) {
		buf[i] = matrix[buf[i]];
	}
}

void permute(unsigned char *buf, const unsigned char *matrix)
{
	unsigned char out[16];
	int i, j, bit, byte;
	memset(out, 0, 16);
	for (i = 0; i < 16; i++) {
		for (j = 0; j < 8; j++) {
			if (buf[i] & 1 << (7 - j)) {
				byte = matrix[i * 8 + j] / 8;
				bit = matrix[i * 8 + j] % 8;
				out[byte] |= 1 << (7 - bit);
			}
		}
	}
	memcpy(buf, out, 16);
}

void xor(unsigned char *buf, const unsigned char *key)
{
	int i;
	for (i = 0; i < 16; i++) {
		buf[i] ^= key[i];
	}
}

int decrypt(const unsigned char *key, const char *infile, const char *outfile)
{
	unsigned char buf[16];
	int result = 0, read_count = 0;
	FILE *fi = NULL, *fo = NULL;

	fail_null(fi, fopen, infile, "rb");
	fail_null(fo, fopen, outfile, "wb");

	while ((read_count = fread(buf, 16, 1, fi)) == 1) {
		permute(buf, iP2);
		substitute(buf, iS2);
		xor(buf, key);
		permute(buf, iP1);
		substitute(buf, iS1);
		if (fwrite(buf, 16, 1, fo) != 1)
			fail_not_zero(ferror, fo);
	}

	fail_not_zero(ferror, fi);

done:
	if (fi) {
		fclose(fi);
		fi = NULL;
	}
	if (fo) {
		fclose(fo);
		fo = NULL;
	}

	return result;
}

int encrypt(const unsigned char *key, const char *infile, const char *outfile)
{
	unsigned char buf[16];
	int result = 0, read_count = 0;
	FILE *fi = NULL, *fo = NULL;

	fail_null(fi, fopen, infile, "rb");
	fail_null(fo, fopen, outfile, "wb");

	while ((read_count = fread(buf, 16, 1, fi)) == 1) {
		substitute(buf, S1);
		permute(buf, P1);
		xor(buf, key);
		substitute(buf, S2);
		permute(buf, P2);
		if (fwrite(buf, 16, 1, fo) != 1)
			fail_not_zero(ferror, fo);
	}

	fail_not_zero(ferror, fi);

done:
	if (fi) {
		fclose(fi);
		fi = NULL;
	}
	if (fo) {
		fclose(fo);
		fo = NULL;
	}

	return result;
}

int main(int argc, char *argv[])
{
	char *key, *file_in_name, *file_out_name, *arg;
	int mode = ENCRYPT, args = 1;

	while (arg = argv[args++]) {
		if (arg[0] == '-') {
			if (arg[1] == '-')
				break;
			else if (arg[1] == 'd')
				mode = DECRYPT;
			else if (arg[1] == 'e')
				mode = ENCRYPT;
			else
				fprintf(stderr, "%s: invalid argument '-%c'\n", basename(argv[0]), arg[1]);
		} else {
			args--;
			break;
		}
	}

	key = argv[args++];
	file_in_name = argv[args++];
	file_out_name = argv[args++];

	if (mode)
		return decrypt(key, file_in_name, file_out_name);
	else
		return encrypt(key, file_in_name, file_out_name);
}
